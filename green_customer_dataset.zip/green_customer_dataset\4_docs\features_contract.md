# Features contract (must be followed by every downstream model)

1. **Only feature-safe tables may feed features.** These are `customers`, `vehicles`, `energy_usage`, `digital_usage`, `products_pre_cutoff` and `transactions`. Every row is dated on or before `CUTOFF_DATE` (2026-06-30), and `validate.py` enforces this.
2. **Never use as features:**
   - `labels.parquet`, including `take_up_date`
   - anything under `data/_internal/` (latents, scenario tags, true propensities, build info)
   - `splits.csv`, other than for selecting rows
3. **`true_category` and `true_subtype` are labels for the transaction categoriser (FR2).** Propensity features built from transactions must use the categoriser's **predicted** category. The `quick_features.py` smoke tests are the only exception: they are a data sanity check and are not used for modelling.
4. **Fit every statistic on TRAIN only:** scalers, imputers, bucket and threshold cut-points (e.g. "high fuel spend" = top quartile on train), target or frequency encodings, calibration curves, and reason-code thresholds. Then apply them unchanged to val and test.
5. **Use val for model selection, early stopping, calibration and confidence-bucket reliability.** Test is touched once, for the final reported metrics and the submitted test-set predictions.
6. **Splits are by `customer_id`** (70/15/15, stratified by region × any 30-day take-up, fixed seed). A customer's rows never cross splits.
7. **The primary label is `label_30d`.** `label_7d` and `label_14d` are reported as supplementary windows. The window used must always be stated.
8. **Eligibility and exclusions are rules, not model outputs.** They are derived from observed data, for example EV owner → no EV Finance. Excluded customers are still scored, but must never be recommended.
