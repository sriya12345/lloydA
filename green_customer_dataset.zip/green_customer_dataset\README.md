# Green Customer Insights dataset: start here

This folder has everything you need to build the take-up prediction models for the four green products. Read this page first. It takes about 10 minutes.

## 1. What this data is

- **Fake but realistic bank data for 20,000 UK customers.** No real person or real bank data is used. The numbers were tuned to match public UK statistics, for example 62.5% of people own their home (Census 2021), 77% of households have a car, and the petrol/diesel/hybrid/electric car mix and typical electricity and gas use match published averages.
- **24 months of history**, from 1 July 2024 to **30 June 2026**. That last date is the **cutoff**: it is "today" from the bank's point of view.
- **The question we are answering:** given everything the bank knew on 30 June 2026, which customers will take up each green product in the next 7, 14 or 30 days?

| Product | What it is | Who can get it | Take-up within 30 days |
|---|---|---|---|
| EV Finance | Loan to swap a petrol, diesel or hybrid car for an electric one | Anyone not already driving an electric car | 710 customers (3.5%) |
| Green Home Loan | Loan for insulation, heat pump or glazing | Home owners only | 513 (2.6%) |
| Solar Finance | Loan for solar panels | Home owners without solar already | 392 (2.0%) |
| Paperless Banking | Switch statements from paper to online | Customers still getting paper statements | 3,035 (15.2%) |

## 2. What's in the folder

```
green_customer_dataset/
├── README.md                   <- this file
├── 1_modelling_table/          <- START HERE: one file, ready to model
│   ├── customer_model_table.csv          one row per customer (20,000 x 116)
│   └── customer_model_table_columns.csv  what every column is and how to use it
├── 2_raw_tables/               <- the original tables, if you want to build new features
├── 3_reference/                <- product rules and CO2 factors (for the carbon / impact part)
└── 4_docs/                     <- full technical detail, only if you need it
```

**For modelling you only need `1_modelling_table/customer_model_table.csv`.** The rest is there to build extra features, to work on the carbon calculations, or to look up detail.

## 3. The modelling table, column by column

Each row is one customer. The 116 columns fall into four groups, and **the group decides how you may use the column.**

| Group | How to spot it | Count | How to use it |
|---|---|---|---|
| ID and split | `customer_id`, `split` | 2 | `split` says whether a row is train, val or test. **Never a model input.** |
| Features | everything else | 98 | **The model inputs.** |
| Eligibility | names start with `elig_` | 4 | 1 = the customer is allowed this product. **Not a model input**; use it to filter rows. |
| Labels | names start with `y_` | 12 | **What you predict.** 1 = took the product up. |

### Features (what the bank knew on 30 June 2026)

| Topic | Example columns | In plain words |
|---|---|---|
| About the customer | `age`, `income_band`, `income_rank`, `region`, `urban`, `home_owner`, `sustainability_preference` | Basic profile. `sustainability_preference` is a 1–5 survey answer, and 36% didn't answer. |
| Car | `has_vehicle`, `fuel_type`, `is_bev`, `vehicle_age`, `annual_mileage` | Empty for customers with no car. |
| Home energy (last 12 months) | `elec_kwh_mean_12m`, `gas_kwh_mean_12m`, `has_gas`, `elec_summer_winter_ratio`, `elec_kwh_yoy_ratio` | Monthly electricity and gas use. `_yoy_ratio` compares this year with last year. |
| Digital banking | `paper_statements_last`, `digital_tx_mean_3m`, `branch_visits_12m`, `digital_tx_yoy_ratio` | How much they use the app or online banking versus paper and branches. |
| Products held | `has_mortgage`, `has_savings`, `balance_savings`, `relationship_tenure_years` | What they already hold with the bank. |
| Spending (last 12 months) | `spend_fuel_12m`, `spend_electricity_12m`, `share_fuel_12m`, `spend_home_improvement_3m`, `has_export_credit` | Card and direct-debit spend per category. `has_export_credit` = they get paid for solar power they export, so they already have panels. |

Missing values (blank cells) are kept on purpose. Section 6 explains how to fill them.

### Labels

There are 12 label columns: 4 products × 3 time windows. For example, `y_ev_finance_30d` = 1 if the customer took EV Finance within 30 days after the cutoff.

- **Use the 30-day labels as the main target.** The 7- and 14-day labels are extra results to report.
- They are nested: anyone who is 1 at 7 days is also 1 at 14 and 30 days.
- Positives are rare for three of the products (2–3.5%), so judge models with **PR-AUC** as well as ROC-AUC, not with accuracy.

### Eligibility

`elig_ev_finance`, `elig_green_home`, `elig_solar` and `elig_paperless` are simple business rules, worked out from the data:
- an electric-car driver can't get EV Finance;
- a renter can't get a Green Home Loan or Solar Finance;
- a home that already has solar panels can't get Solar Finance;
- a customer who is already paperless can't get Paperless Banking.

**Train and score each product only on customers with `elig_... = 1`.** Nobody who is ineligible took the product up, so the rows with `elig_... = 0` only add noise.

## 4. How the train / val / test split was made

Every **customer** is in exactly one group:

| Group | Customers | Share | What it is for |
|---|---|---|---|
| train | 14,003 | 70% | fitting models |
| val | 2,997 | 15% | comparing models, tuning, choosing thresholds |
| test | 3,000 | 15% | **the final score, used once at the very end** |

The split was made on three rules:

1. **By customer, not by row.** One person's data never ends up in two groups. Otherwise a model could "recognise" a customer it saw during training and look better than it really is.
2. **Balanced by region and by "did they take up anything".** Customers were sorted into buckets of region × (took up at least one product within 30 days: yes/no). Each bucket was split 70/15/15. So every region, and the rare positive customers, are spread evenly. The check confirms it: every region is 70/15/15, and 21.5% of customers in every group took something up.
3. **Fixed random seed (20260630).** The split is the same every time the data is rebuilt.

Positives per group (30-day labels):

| Product | train | val | test |
|---|---|---|---|
| EV Finance | 492 | 106 | 112 |
| Green Home | 354 | 80 | 79 |
| Solar | 274 | 58 | 60 |
| Paperless | 2,136 | 458 | 441 |

## 5. What has already been done

1. **Generated the data.** Each step builds on the previous one, the way real life does:
   customers → cars and homes → products held → monthly energy and digital activity → 13.1 million card and direct-debit transactions → who takes up which product.
   The take-up labels follow sensible patterns, for example a high fuel spender with an old car is more likely to want EV Finance. There is also hidden randomness and hidden personality traits, so no model can be perfect. About 0.86 ROC-AUC is the best possible.
2. **Planted tricky customers** (about 6%) to test the system: customers with missing data, conflicting signals (e.g. fuel spending but no car on record), and changed circumstances (e.g. sold their car). These are not flagged in the data, on purpose.
3. **Checked everything automatically.** 26 checks: the numbers add up, no future information leaks into the features, and labels are learnable but not too easy. All passed (`4_docs/data_profile.md`).
4. **Built a transaction categoriser.** It reads each statement line, e.g. `CARD PAYMENT TO TESCO PFS ON 03/05`, and puts it into one of 8 categories: Fuel, Electricity, Gas, Public Transport, Home Improvement, Automotive, Utilities, Other. It is 99% accurate on customers it never saw. The spend features in the modelling table come from **its predictions, not from the true answers**, so the model gets the same imperfect information it would have in real life. Detail: `4_docs/categoriser_results.md`.
5. **Built the modelling table:** all tables turned into one row per customer, using only data up to the cutoff.

**Quick baseline:** an untuned gradient-boosting model on this table gets a val ROC-AUC of about 0.68 (EV Finance), 0.65 (Green Home), 0.69 (Solar) and 0.81 (Paperless). There is room to improve.

## 6. Rules to follow (so results are honest)

1. **Inputs = feature columns only.** Never use `y_*`, `elig_*`, `split` or `customer_id` as model inputs.
2. **Learn anything from train only.** This covers filling in missing values (e.g. the median), scaling, encoding categories, and thresholds such as "high fuel spend = top 25%". Work them out on train rows, then apply the same values to val and test.
3. **Use val for all decisions.** Don't look at test until the final model is chosen, then score it once.
4. **Always say which window you report.** The default is 30 days.
5. **Recommend only to eligible customers.** You may still give everyone a score, but only recommend a product when `elig_... = 1`.

## 7. Suggested next steps

1. A model per product (e.g. logistic regression as a baseline, then LightGBM or XGBoost), trained on eligible train rows and checked on val with ROC-AUC and PR-AUC.
2. Turn the scores into recommendations, with a reason for each, e.g. "high fuel spend, older petrol car".
3. **Carbon impact per recommendation:** use `3_reference/emissions_factors.csv` and `assumptions.csv` with each customer's mileage and energy use. `green_products.csv` gives the formula for each product.
4. Check the tricky cases: missing data, a customer with fuel spending but no car on record, and so on.

## 8. Good to know

- **It's synthetic.** We designed how customers behave, so a good score means the model recovered our design, not that real customers would act this way.
- `2_raw_tables/labels.csv` contains `take_up_date`. That is after the cutoff, so **never use it as a feature.**
- The 13-million-row transactions file (235 MB) is **not** included. You only need it to build new spend features or to rework the categoriser; ask for it if you do.
- Full detail: `4_docs/data_card.md` (the whole dataset), `label_generation.md` (how take-ups were simulated), `category_rules.md` (transaction categories) and `features_contract.md` (the modelling rules).
