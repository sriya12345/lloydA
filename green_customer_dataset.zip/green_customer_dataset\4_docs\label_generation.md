# Label generation

There are two kinds of label:
- **Transaction category:** `true_category` / `true_subtype`. It comes from the generation path; see `category_rules.md`.
- **Customer × product take-up:** `labels.parquet`. Its generation is described below.

All numbers come from `data_gen/config.yaml` → `labels`. The solved intercepts and realised rates for the current build are in `reports/data_profile.md`.

## 1. Timeline
- History: **2024-07-01 → 2026-06-30** (24 months). **CUTOFF_DATE = 2026-06-30** is the last observable day.
- Take-up events happen strictly **after** the cutoff. Windows are **7, 14 and 30 days** and can be configured; adding 60 or 90 only needs a config change.
- `labels.parquet` holds `customer_id, product, take_up_date, label_7d, label_14d, label_30d`. It has no month or date column that could be joined to feature tables.

## 2. Propensity model (per customer × product)

```
logit(p) = b0 + Σ_k  coef_k · driver_k  + σ · ε,      ε ~ N(0, 1)
p        = 0                                      if the customer is hard-excluded
```

- `p` is the probability of take-up **within 30 days** (the reference window).
- **b0 is solved, not hand-tuned.** Bisection (`calibrate.solve_intercept`) finds the value at which the share of **all** customers taking up within 30 days equals the target. Excluded customers count as zeros.
- `z_*` drivers are z-scored over the product's eligible population. `*_flag` drivers are 0/1.
- **Drivers come from the true pre-cutoff state**, i.e. before the observation layer hides data. Customers act on their real circumstances even when the bank's data is incomplete. A customer whose vehicle row is missing still has a car-driven EV propensity. That makes such customers harder to score, which is realistic and deliberate.
- **Latent traits** are unobserved and written only to `data/_internal/latents.parquet`. Together with ε, they keep labels from being a deterministic function of observable features.
- The observed `sustainability_preference` is only a noisy 1–5 survey proxy of `green_mindedness`, and about 36% of customers did not respond.

### Coefficients

**EV_FINANCE.** Target 30-day rate 3.5%, σ = 0.9.

| driver | coef | meaning |
|---|---|---|
| z_log_fuel_spend | 0.55 | last-12-month fuel £ (litres × pump price) |
| z_log_mileage | 0.35 | last-12-month miles |
| vehicle_finance_flag | 0.55 | car on finance (with the bank or another lender) |
| older_vehicle_flag | 0.30 | vehicle age ≥ 8 years |
| z_income | 0.30 | income rank |
| hybrid_flag | 0.25 | current car is a hybrid |
| no_car_flag | −2.20 | no car at the cutoff (allowed, but unlikely) |
| green_mindedness (latent) | 0.75 | |
| financial_activeness (latent) | 0.55 | |

**GREEN_HOME.** Target 2.5%, σ = 0.9.

| driver | coef | meaning |
|---|---|---|
| z_log_energy_spend | 0.55 | last-12-month electricity + gas £ |
| z_log_gas_kwh | 0.30 | heating demand |
| old_property_flag | 0.40 | pre-1950 / poorly insulated. Hidden, but raises gas use |
| mortgage_flag | 0.35 | has a mortgage (with any lender) |
| z_home_improvement | 0.30 | last-12-month home-improvement £ |
| z_income | 0.25 | |
| green_mindedness (latent) | 0.80 | |
| financial_activeness (latent) | 0.55 | |

**SOLAR.** Target 2.0%, σ = 0.9.

| driver | coef | meaning |
|---|---|---|
| z_log_elec_kwh | 0.55 | last-12-month grid electricity |
| z_solar_yield | 0.35 | regional kWh/kWp (PVGIS) |
| z_property_size | 0.30 | roof-size proxy |
| london_flag | −0.40 | fewer suitable roofs (flats) |
| z_income | 0.30 | |
| green_mindedness (latent) | 0.85 | |
| financial_activeness (latent) | 0.50 | |

**PAPERLESS.** Target 15.0%, σ = 0.8.

| driver | coef | meaning |
|---|---|---|
| z_log_digital_tx | 0.55 | last-6-month mean digital transactions |
| z_branch_visits | −0.30 | last-6-month branch visits |
| online_registered_flag | 0.80 | registered for online/app banking |
| z_digital_trend | 0.20 | recent rise in digital use |
| digital_affinity (latent) | 0.70 | |
| financial_activeness (latent) | 0.35 | |

## 3. Hard exclusions (p forced to 0)

| product | excluded when | catalogue rule |
|---|---|---|
| EV_FINANCE | the customer drives a battery EV at the cutoff (this includes customers who switched during the history) | no replacement use case |
| GREEN_HOME | not a home owner at the cutoff | needs home ownership |
| SOLAR | not a home owner, **or** the home already has PV | needs ownership; existing PV is visible via SEG credits |
| PAPERLESS | no paper statements in the last pre-cutoff month | already paperless |

## 4. Take-up date and windowed labels
Each eligible customer gets a time to take-up `T` (days after the cutoff) drawn from a Weibull distribution:

```
T   = λ · (−ln U)^(1/k),   U ~ Uniform(0,1),   k = 0.8
λ   = 30 / (−ln(1 − p))^(1/k)          ⇒  P(T ≤ 30) = p exactly
label_w = 1[ ceil(T) ≤ w ]              for every window w
take_up_date = CUTOFF + ceil(T) days    (null if ceil(T) > max window)
```

- Shape k < 1 front-loads take-ups, the way people respond soon after a nudge. Customers with higher propensity also adopt sooner.
- Labels are **nested** by construction. A take-up on day 20 counts as 0 at 7 days, 0 at 14 days and 1 at 30 days.

## 5. Realised base rates (default build: 20,000 customers, seed 20260630)

| product | eligible | 7d | 14d | 30d |
|---|---|---|---|---|
| EV_FINANCE | 95.5% | 218 (1.1%) | 379 (1.9%) | 710 (3.5%) |
| GREEN_HOME | 63.1% | 172 (0.9%) | 296 (1.5%) | 513 (2.6%) |
| SOLAR | 58.0% | 127 (0.6%) | 222 (1.1%) | 392 (2.0%) |
| PAPERLESS | 40.6% | 1,349 (6.7%) | 2,057 (10.3%) | 3,035 (15.2%) |

Every product/window has at least 100 positives. The build warns if any falls below this.

## 6. Learnability check (realism of the labels)
`validate.py` fits logistic regression and gradient boosting on simple pre-cutoff aggregates (train → val, among rule-eligible customers).

| product | ROC-AUC (best) | oracle |
|---|---|---|
| EV_FINANCE | 0.72 | 0.87 |
| GREEN_HOME | 0.74 | 0.86 |
| SOLAR | 0.73 | 0.87 |
| PAPERLESS | 0.83 | 0.86 |

- All four sit in the target band of **0.70–0.85**, well below the 0.92 warning level.
- The **oracle** (the hidden true propensity) reaches 0.86–0.87. The gap between model and oracle is the unobservable latent and noise share.
- Shuffled-label and customer-id-only models score ≈ 0.50, and no single feature exceeds an AUC of 0.90.

To make the labels harder, raise `noise_sd` or the latent coefficients. To make them more learnable, lower them.
