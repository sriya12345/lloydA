# Transaction category rules (FR2)

Every transaction has exactly one `true_category` from these eight mutually exclusive classes:
**Fuel, Electricity, Gas, Public Transport, Home Improvement, Automotive, Utilities, Other.**

The generator decides `true_category` from **what was actually bought** (the generation path), not from the merchant string. This means the same string can carry different categories, as in real statements. `true_subtype` gives the finer generation path, which helps with error analysis. Both columns are **labels** for the categoriser. Propensity features must use the categoriser's predictions, not these columns (see `data_gen/features_contract.md`).

## Category definitions

| Category | Includes | Excludes (and where it goes) |
|---|---|---|
| Fuel | Petrol, diesel and hybrid fuel bought at a forecourt, including supermarket forecourts (`TESCO PFS`, `ASDA PETROL`, `SAINSBURYS PETROL`) | Forecourt shop purchases (Other); EV charging (Electricity) |
| Electricity | Household electricity bills (DD); EV public charging (`POD POINT`, `IONITY`, `SHELL RECHARGE`, `BP PULSE`); Smart Export Guarantee credits for exported PV power | Gas part of a split dual-fuel bill (Gas) |
| Gas | Household mains gas bills (DD) | — |
| Public Transport | Rail, bus, tram, metro/underground, coach, ferry (`TFL TRAVEL CH`, `TRAINLINE`, `SCOTRAIL`, `STAGECOACH BUS`) | Taxis and ride-hailing (Other) |
| Home Improvement | DIY, building and trade merchants, and large home projects such as kitchens, windows and boilers (`B&Q`, `WICKES`, `SCREWFIX`, `HOWDENS JOINERY`, `SAFESTYLE WINDOWS`) | Furniture and homewares (`IKEA`, `DUNELM`), which are Other |
| Automotive | Car insurance, vehicle tax (`DVLA-…`), MOT, servicing, car parts, parking, tolls and the congestion charge | Fuel (Fuel); car-finance repayments (Other); bicycles (Other) |
| Utilities | Water, council tax / NI rates, broadband, mobile, TV licence | Electricity and gas (their own categories) |
| Other | Groceries, dining, retail, subscriptions, taxis, cash withdrawals, transfers, rent, mortgage and loan repayments (including car finance), salary and pension credits, forecourt kiosk purchases, bicycles | — |

## Boundary decisions

| # | Case | Rule | Why |
|---|---|---|---|
| 1 | `TESCO PFS 2441 READING` (fuel) vs `TESCO STORES` (groceries) | PFS / PETROL / FUEL forecourt lines are **Fuel**. Supermarket store lines are **Other**. | The forecourt sells road fuel and the store does not. |
| 2 | Forecourt kiosk purchase (same `SHELL` / `TESCO PFS` string, ~£1.50–£9.50) | **Other**. The ground truth is the purchase, so the text alone is ambiguous and the amount is the main clue. | Snacks are not transport fuel. Including these tests whether the categoriser uses amount as well as text. |
| 3 | `HALFORDS` car parts vs `HALFORDS` bikes | Parts are **Automotive** (~£10–£80). Bikes are **Other** (~£150–£800). `HALFORDS AUTOCENTRE` (MOT/servicing) is **Automotive**. | A bike is not a vehicle running cost. |
| 4 | EV public charging (`SHELL RECHARGE`, `BP PULSE`) vs `SHELL` / `BP` fuel | Charging is **Electricity**, never Fuel. | It is grid electricity. The carbon engine applies the grid factor, not the petrol factor. |
| 5 | Dual-fuel bill from one supplier, **split** into two lines (`DD OCTOPUS ENERGY ELEC` / `DD OCTOPUS ENERGY GAS`) | Each line takes its fuel's category: **Electricity** / **Gas**. | Electricity and gas spend stay separately observable for the Green Home and Solar signals. |
| 6 | Dual-fuel bill arriving as **one unsplit line** (`DD OCTOPUS ENERGY`, ~15% of dual-fuel customers) | The line takes the category of the **larger share of the bill**: **Gas** if gas £ ≥ electricity £, otherwise **Electricity**. | It must be exactly one category. The majority rule is deterministic and documented. The true split is recoverable from `energy_usage`. |
| 7 | A supplier string that does not name the fuel (e.g. `DD BRITISH GAS` supplying electricity) | The category is the **fuel supplied**, regardless of the brand name. | Brand names are not reliable fuel indicators. |
| 8 | Water | **Utilities** (not Electricity/Gas). Scotland and NI have no separate water DD, because Scottish water is collected with council tax and NI domestic water is not billed. | It follows the brief's split between energy and other utilities. |
| 9 | SEG export credit (`OCTOPUS ENERGY SEG EXPORT`, credit) | **Electricity** (credit). | It is electricity-related and also an observable signal of existing PV. |
| 10 | Car finance / vehicle loan repayments, mortgage, rent | **Other**. | These are financial flows, not running costs or emissions activities. |
| 11 | Taxis / ride-hailing (`UBER *TRIP`, `BOLT.EU`) | **Other**. | These are private car journeys, not public transport. |
| 12 | Parking, tolls, congestion charge | **Automotive**. | They are a cost of running a car. |
| 13 | EV owner with regular forecourt fuel (planted conflicting signal) | **Fuel**. The ground truth is a second household car. | The category is based on the purchase. The conflict is resolved at recommendation time (the BEV record wins for EV Finance). |
| 14 | Credits in general (salary, pension) | **Other**, `debit_credit = credit`. | They are not sustainability activities. |

## Text noise the categoriser must handle
Statement lines vary like real exports:
- Formats: `CARD PAYMENT TO … ON dd/mm`, `CONTACTLESS …`, store numbers, towns, motorway junctions, `DD` / `DIRECT DEBIT … <ref>`, `SO` / `FPO`.
- Upper/lower/title casing, truncation to 16–24 characters, double spaces, and roughly 2% typos (dropped or swapped letters).

All noise rates are in `config.yaml` → `transactions.text_noise`.
