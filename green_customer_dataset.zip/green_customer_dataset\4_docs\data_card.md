# Data card: synthetic Green Customer Insights dataset

**Fully synthetic.** No real personal or banking data was used. Public aggregate statistics (ONS, Census 2021, DfT, Ofgem, DESNZ, PVGIS, Zapmap) are used only as calibration targets.

**Reproduce:** run `python -m data_gen.build`. It uses a fixed seed (20260630), takes about 1.5 minutes on a laptop, and includes validation. Every tunable number, with its source, lives in `data_gen/config.yaml`.

## 1. Purpose
The dataset supports the four required green opportunities (EV Finance, Green Home Loan, Solar Finance, Paperless Banking) and the functional requirements FR1–FR7:
- a Customer 360 view
- transaction categorisation with ground-truth labels
- take-up propensity labels per window
- carbon-engine inputs (mileage, fuel litres, kWh, statements) with a shared factor and assumption file
- planted scenario customers for robustness tests

## 2. Files

| File | Grain | Rows (default) | Feature-safe? |
|---|---|---|---|
| `data/customers.parquet` | customer | 20,000 | yes |
| `data/vehicles.parquet` | customer with a car at cutoff | ~15,300 | yes |
| `data/energy_usage.parquet` | customer × month | ~471,000 | yes |
| `data/digital_usage.parquet` | customer × month | ~478,000 | yes |
| `data/transactions.parquet` | transaction | ~13.1M | yes (except the `true_*` label columns) |
| `data/products_pre_cutoff.parquet` | holding | ~50,500 | yes |
| `data/green_products.csv` | product | 4 | reference |
| `data/emissions_factors.csv` | factor | 11 | reference (carbon engine) |
| `data/assumptions.csv` | assumption | ~110 | reference (carbon engine) |
| `data/labels.parquet` | customer × product | 80,000 | **NO**, outcomes after the cutoff |
| `data/splits.csv` | customer | 20,000 | row selection only |
| `data/_internal/latents.parquet` | customer | 20,000 | **NO**, hidden traits |
| `data/_internal/scenario_tags.csv` | tag | ~1,250 | **NO**, scenario tests only |
| `data/_internal/true_propensity.parquet` | customer × product | 80,000 | **NO**, oracle analysis only |

## 3. Schema

**customers:**
- `customer_id` (random `C1xxxxx`)
- `age` (18–85)
- `income_band` (<20k / 20-35k / 35-50k / 50-75k / 75k+, nullable)
- `postcode_district` (real area letters + random district number, nullable)
- `region` (12 UK ITL1 regions)
- `urban_rural`
- `home_owner` (at cutoff)
- `digital_usage` (none/low/medium/high, from the last 3 months of digital transactions)
- `sustainability_preference` (1–5 survey score, nullable)
- `data_snapshot_date` (= cutoff)

**vehicles:**
- `customer_id`
- `vehicle_type` (hatchback/saloon/estate/suv/mpv)
- `fuel_type` (petrol/diesel/hybrid/bev)
- `vehicle_age` (years, nullable)
- `annual_mileage` (miles over the last 12 months, nullable)

Customers with no car have no row.

**energy_usage:** `customer_id`, `month` (month start), `electricity_kwh` (grid import, including EV home charging, net of PV self-use), `gas_kwh` (0 for electrically heated homes).

**digital_usage:** `customer_id`, `month`, `digital_statements`, `paper_statements`, `digital_transactions`, `branch_visits`.

**transactions:**
- `transaction_id` (int)
- `customer_id`
- `date`
- `merchant_description` (raw statement text)
- `amount` (GBP, positive)
- `debit_credit`
- `true_category` (the 8 FR2 categories)
- `true_subtype` (generation path)

**products_pre_cutoff:**
- `customer_id`
- `product`: current_account, savings, credit_card, mortgage, vehicle_loan, ev_finance, personal_loan, investments, paperless_banking
- `start_date`, `end_date` (if closed before the cutoff)
- `balance` (at cutoff)
- `status` (active/closed as of the cutoff)

**green_products:** GP01–GP04 with `category`, `intended_use_cases`, `exclusion_rules` and `sustainability_metric`. Green Home covers efficiency upgrades (insulation, heat pump, glazing). Solar covers PV installation. Both require home ownership.

**emissions_factors:**
- Columns: `activity`, `unit`, `kg_co2e_per_unit`, `source`, `year`, `note`, `verify`.
- All come from **UK Government GHG Conversion Factors 2025 (DESNZ)**, one consistent year: petrol/diesel per litre; petrol/diesel/hybrid/BEV car per km; grid electricity and T&D per kWh; natural gas per kWh; paper per tonne.

**assumptions:**
- Car efficiencies, EV kWh/km, home-charging share, PV system size, self-consumption, heat-pump SCOP, boiler efficiency, insulation saving, paper sheet mass, sheets per statement.
- Regional PV yield.
- Ofgem price-cap rates by quarter, DESNZ monthly pump prices, the public charging price and the SEG rate.

Both the generator and the carbon engine read these through `data_gen/reference.py`, so they can never disagree.

## 4. Generation process (causal order)
Each stage only uses outputs of earlier stages. No table is generated independently and joined afterwards.
1. **Customers.**
   - Age comes from ONS band shares. Region comes from ONS mid-2025 shares, with an urban share per region.
   - Income is a latent score (an age hump, minus a retirement penalty, plus a regional earnings effect, plus noise), cut into bands that hit the target shares.
   - Tenure is a logistic in age, income, London and urban status, with its intercept solved to Census 62.5%.
   - Owners hold a mortgage with an age-dependent probability.
2. **Latent traits** (hidden): `green_mindedness` (slightly younger and richer), `financial_activeness`, and `digital_affinity` (strongly age-linked, r ≈ −0.66).
3. **Lifestyle.**
   - Car ownership is calibrated to 77%, lower in London.
   - Fuel type is a multinomial logit (BEV more likely with income, green-mindedness and ownership), solved to the DfT Q2-2026 mix.
   - Vehicle age follows a gamma distribution. Mileage is lognormal (×rural, ×commuter, ×diesel), mean ≈ 7,100.
   - Also generated: electric heating (with regional off-gas extras), old property, property size, and existing PV (≈8% of owners).
   - Life events for the changed-circumstance scenarios: EV switch, car sold, renter → owner.
4. **Product holdings:** mortgage only for owners, vehicle finance only for car owners, investments and savings follow income.
5. **Monthly activity.**
   - Mileage with seasonality feeds litres via efficiency, and EV kWh is split into home and public charging.
   - Electricity and gas are calibrated to Ofgem TDCV (medium 2,700 / 11,500 kWh) with seasonal profiles, electric heating, EV home charging and PV self-use.
   - Digital activity is driven by `digital_affinity` with slow upward trends; branch visits slowly decline.
   - Paper statements follow inertia: a segment is highly digital yet still on paper (the Paperless target).
6. **Transactions**, derived from activity:
   - fuel fill-ups = litres × monthly DESNZ pump price
   - EV public charging kWh × 75p
   - energy DD = kWh × Ofgem unit rate + standing charge × days
   - SEG credits; salary/pension; rent, mortgage and loan repayments (amortised); insurance, VED, MOT, servicing, parts, parking; water, council tax, broadband, mobile, TV licence; public transport (urban/no-car/London heavy); home improvement (owners, old homes); discretionary "Other" spend (≈56% of rows)
7. **Labels:** a documented logistic propensity, then Weibull time-to-event after the cutoff, giving 7/14/30-day labels. See `label_generation.md`.
8. **Observation layer:** planted scenarios plus general missingness are applied to the observed tables.
9. **Splits:** 70/15/15 by customer, stratified by region × any take-up.

## 5. Calibration sources (verified, see config `source` fields)

| Quantity | Source | Target | Generated |
|---|---|---|---|
| Home ownership | ONS Census 2021 TS054 | 62.5% | 63.1% |
| Households without a car | DfT NTS 2024/25 (NTS0205a, NTS9902a) | 23% (London ~49%) | 23% (London 48%) |
| Car fuel mix | DfT VEH1103, Q2 2026 | 54/28/12/6% | 54/28/12/6% |
| Annual mileage | DfT NTS0901a 2025 | 7,100 mi | ~7,150 mi |
| Electricity / gas use | Ofgem TDCV (2023 values, in force to Jun 2026) | 2,700 / 11,500 kWh | 2,673 median / 11,550 mean |
| Region shares | ONS mid-2025 MYE2 | — | within 0.4 pp |
| Emissions factors | DESNZ GHG Conversion Factors 2025 | — | — |
| Price cap | Ofgem quarterly cap notices | — | — |
| Pump prices | DESNZ weekly road fuel prices | — | — |
| Solar yield | EU JRC PVGIS v5.3 | — | — |
| Public charging price | Zapmap | — | — |
| Existing PV | DESNZ solar deployment | — | — |

The pump prices include the real price spike from March 2026 (diesel ~190p/L in April 2026).

**Approximate values** (flagged `verify: true` in config) include:
- age band shares, income band shares, urban shares and regional income effects
- the electric-heating share, gas seasonal profile and electric-heating demand
- regional PV yields interpolated between PVGIS points
- vehicle efficiencies, EV kWh/km and the home-charging share
- heat-pump SCOP, the insulation saving and sheets per statement

## 6. Planted scenarios (~6% of customers, internal tags only)

| Scenario | Sub-types | Expected system behaviour (in tags) |
|---|---|---|
| MISSING_DATA | no vehicle row; missing energy months; null income; null preference | degrade gracefully, lower confidence |
| CONFLICTING_SIGNALS | fuel spend with no vehicle record; renter with a mortgage-like DD; EV owner with forecourt fuel | flag the conflict; rules win |
| SHOULD_NOT_RECOMMEND | EV owner; renter with high electricity; already paperless | never recommend the excluded product |
| INSUFFICIENT_IMPACT_DATA | no mileage and no fuel transactions; no energy data at all | impact = null with a reason |
| CHANGED_CIRCUMSTANCES | switched to an EV; sold car; renter → owner during the history | use the current state |

General missingness is applied to everyone:
- income 3%, postcode 1%, vehicle age 2%, mileage 4%
- energy months 1.5%, digital months 0.5%
- survey non-response ~36%

## 7. Leakage prevention
- **Cutoff:** every feature-table row is dated on or before 2026-06-30. Take-ups happen only after it and live in a separate file with no joinable date.
- **Holdings:** product status is as of the cutoff. Green take-ups after the cutoff never appear in holdings.
- **Hidden fields:** latent traits, scenario tags and true propensities sit in `data/_internal/`. `validate.py` checks that none of their columns appear in feature tables, and that no observed feature correlates above 0.95 with a latent.
- **IDs:** customer IDs are a random permutation, and the id-only and row-order model scores ≈ 0.50.
- **Splits:** customer-level and disjoint. All fitted statistics must use train only (`data_gen/features_contract.md`).
- **Smoke tests:** shuffled-label ≈ 0.50; no single feature has AUC > 0.90; model AUC 0.72–0.83, against an oracle of 0.86–0.87.

## 8. Limitations (read before interpreting results)
- **Designed relationships.** We designed every behavioural relationship ourselves: take-up drivers, coefficients, latent effects and noise levels. Model performance therefore reflects how well a model recovers *our assumptions*, not real customer behaviour. Metrics should not be read as evidence of real-world take-up rates or effect sizes.
- **Aggregate calibration only.** Calibration uses published aggregates (means, shares), not individual records. Joint distributions (e.g. income × mileage × tenure) are plausible but not validated against microdata.
- **One factor year.** All emissions factors are DESNZ 2025, a single fixed year. Real grid intensity changes year to year, and 2025 factors are applied to activity from 2024–2026.
- **Simplifications:**
  - Energy direct debits are billed on actual monthly use (no fixed DD with annual reconciliation).
  - Off-gas oil/LPG homes are folded into "electric heating".
  - PHEVs are treated as fuel-only hybrids.
  - Northern Ireland uses GB price-cap rates.
  - Household composition is approximate, and adult-level ownership uses household-level Census rates.
- **Synthetic text.** Merchant strings use real UK brand names as text only, to look realistic. They do not describe real transactions or relationships with those brands. Employers and payees are synthetic.
- **Imposed base rates.** Take-up base rates are design targets (e.g. Paperless 15% in 30 days, consistent with a prompted campaign), not observed market rates.
- **Scenario frequencies.** Scenario customers are over-represented relative to reality, so that robustness tests have enough cases.
